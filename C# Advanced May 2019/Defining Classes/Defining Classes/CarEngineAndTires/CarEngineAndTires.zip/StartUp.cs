﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CarManufacturer
{
    public class StartUp
    {
        public static void Main()
        {
            List<Tire[]> tires = new List<Tire[]>();
            List<Engine> engines = new List<Engine>();
            List<Car> cars = new List<Car>();

            string command = Console.ReadLine();

            //Tires
            while (command != "No more tires")
            {
                Tire[] arr = new Tire[4];
                string[] commandArr = command.Split();
                int index = 0;

                for (int i = 0; i < commandArr.Length; i += 2)
                {
                    int year = int.Parse(commandArr[i]);
                    double pressure = double.Parse(commandArr[i + 1]);

                    Tire tire = new Tire(year, pressure);
                    arr[index++] = tire;
                }

                tires.Add(arr);
                command = Console.ReadLine();
            }

            command = Console.ReadLine();

            //Engine
            while (command != "Engines done")
            {
                string[] arr = command.Split();

                int horsePower = int.Parse(arr[0]);
                double cubicCapacity = double.Parse(arr[1]);

                Engine engine = new Engine(horsePower, cubicCapacity);
                engines.Add(engine);

                command = Console.ReadLine();
            }


            command = Console.ReadLine();

            while (command != "Show special")
            {
                string[] arr = command.Split();

                string make = arr[0];
                string model = arr[1];
                int year = int.Parse(arr[2]);
                double fuelQuantity = double.Parse(arr[3]);
                double fuelConsumption = double.Parse(arr[4]);
                int engineIndex = int.Parse(arr[5]);
                int tiresIndex = int.Parse(arr[6]);

                Engine engine = engines[engineIndex];
                Tire[] tireSet = tires[tiresIndex];

                Car car = new Car(make, model, year, fuelQuantity, fuelConsumption, engine, tireSet);
                cars.Add(car);
                
                command = Console.ReadLine();
            }

            foreach (var car in cars.Where(c => c.Year > 2016 
                        && c.Engine.HorsePower > 330 
                        && (c.Tires.Sum(tire => tire.Pressure) >= 9 && c.Tires.Sum(tire => tire.Pressure) <= 10)))
            {
                car.Drive(20);

                Console.WriteLine(car.WhoAmI());
            }
        }
    }
}
